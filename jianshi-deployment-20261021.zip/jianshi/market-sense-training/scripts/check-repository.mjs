// Check files being committed, not ignored local runtime data. No secret values are printed.
import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
const files=execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0').filter(Boolean);
if(!files.length)throw Error('No tracked files to inspect. Stage source files first.');
const limit=5*1024*1024,problems=[];let total=0,largest={path:'',bytes:0};
for(const file of files){
 if(!fs.existsSync(file)){problems.push(file+': tracked file is missing');continue;}
 const size=fs.statSync(file).size;total+=size;if(size>largest.bytes)largest={path:file,bytes:size};
 if(size>limit)problems.push(file+': exceeds repository policy of 5 MiB per file');
 if(/(^|\/)(work|outputs|node_modules|dist|\.wrangler|\.sites-runtime|\.next|\.vinext|\.agents|\.codex)(\/|$)|(^|\/)\.env(?:\.|$)|\.(?:sqlite(?:-wal|-shm)?|db|pem|key|p12|pfx|tsbuildinfo|zip|gz|tar|7z)$/i.test(file))problems.push(file+': runtime, secret, archive or generated file');
 if(size<=limit){const text=fs.readFileSync(file,'utf8');if(/ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|sk-[A-Za-z0-9_-]{32,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(text))problems.push(file+': possible credential detected');}
}
console.log(JSON.stringify({files:files.length,totalBytes:total,largest},null,2));
if(problems.length){for(const p of problems)console.error(p);process.exitCode=1;}else console.log('Repository size and runtime-file checks passed.');
