// Deterministic synthetic candles for local development. No real market data.
import fs from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
const directory=new URL('../work/corpus/',import.meta.url);
await fs.mkdir(directory,{recursive:true});
const indexFile=new URL('index.json',directory);
try {await fs.access(indexFile);throw new Error('work/corpus/index.json already exists. Existing market data was preserved.');}
catch(error){if(error.code!=='ENOENT')throw error;}
let close=100;
const rows=Array.from({length:650},(_,i)=>{
 const open=close*(1+Math.sin(i*1.71)*.008);close=open*(1+.001+Math.sin(i*.37)*.02);
 const high=Math.max(open,close)*(1+.003+Math.abs(Math.sin(i))*.01),low=Math.min(open,close)*(1-.003-Math.abs(Math.cos(i))*.01);
 return [new Date(Date.UTC(2020,0,1+i)).toISOString().slice(0,10),open,high,low,close,Math.round(100000+Math.abs(Math.sin(i*.7))*400000)];
});
await fs.writeFile(new URL('demo.json.gz',directory),gzipSync(JSON.stringify({code:'DEMO-SYNTHETIC',adjust:'2',rows})),{flag:'wx'});
await fs.writeFile(indexFile,JSON.stringify({stocks:[{key:'demo',count:rows.length}],stats:{eligibleStocks:1},source:'Synthetic development data, not real prices',version:1}),{flag:'wx'});
console.log('Created 650 synthetic daily candles in ignored work/corpus. These are not real market prices.');
