import csv,json,gzip,re,math,pathlib,collections,sys
source=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else r'D:\D.quant\history_data_used')
target=pathlib.Path(__file__).resolve().parents[1]/'work'/'corpus'
target.mkdir(parents=True,exist_ok=True)
stats=collections.Counter(); stocks=[]; flags=collections.Counter()
for file in sorted(source.glob('*.csv')):
    stats['files']+=1
    if not re.fullmatch(r'(sh\.(60|68)\d{4}|sz\.(00|30)\d{4}|bj\.\d{6})_d',file.stem):
        stats['nonStocks']+=1; continue
    rows={}; adjusts=set()
    with file.open(encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            try:
                o,h,l,c,v=[float(r[k]) for k in ['open','high','low','close','volume']]
                if r.get('tradestatus')!='1' or v<=0 or min(o,h,l,c)<=0 or not all(map(math.isfinite,[o,h,l,c,v])) or h<max(o,c,l) or l>min(o,c,h):
                    stats['invalidRows']+=1; continue
                date=r['date']; adjusts.add(r.get('adjustflag',''))
                if date in rows: stats['duplicates']+=1
                rows[date]=[date,round(o,6),round(h,6),round(l,6),round(c,6),int(v)]
            except (ValueError,KeyError): stats['invalidRows']+=1
    if len(rows)<=500: stats['tooShort']+=1; continue
    if len(adjusts)!=1 or next(iter(adjusts)) not in ('1','2'):
        stats['unadjustedOrMixed']+=1; continue
    rows=[rows[k] for k in sorted(rows)]; key=f'{len(stocks):05d}'
    data={'code':file.stem[:-2],'adjust':next(iter(adjusts)),'rows':rows}
    (target/f'{key}.json.gz').write_bytes(gzip.compress(json.dumps(data,separators=(',',':')).encode(),mtime=0))
    stocks.append({'key':key,'count':len(rows)}); flags[data['adjust']]+=1; stats['validRows']+=len(rows)
stats['eligibleStocks']=len(stocks)
index={'stocks':stocks,'stats':dict(stats),'adjustFlags':dict(flags),'source':'本地日频 CSV','version':1}
(target/'index.json').write_text(json.dumps(index,ensure_ascii=False,separators=(',',':')),encoding='utf8')
print(json.dumps({'stats':dict(stats),'adjustFlags':dict(flags),'compressedMB':round(sum(f.stat().st_size for f in target.glob('*.gz'))/1e6,1)},ensure_ascii=False))
