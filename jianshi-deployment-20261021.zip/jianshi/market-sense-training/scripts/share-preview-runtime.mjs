import {createSession,act,present} from '../lib/engine.mjs';
const rows=Array.from({length:650},(_,i)=>{const c=100+i*.08+Math.sin(i*.17)*9+Math.sin(i*.041)*13,o=c+Math.sin(i*1.3)*1.7;return ['演示日'+i,o,Math.max(o,c)+2,Math.min(o,c)-2,c,300000+Math.round((Math.sin(i*.7)+1)*200000)]});
const data={code:'合成演示标的',rows},user={id:'offline-user',nickname:'体验用户'};
const sessions=new Map(),published=new Map();let sequence=0;
function create(name=user.nickname,start=0){const s=createSession('demo',start,{feeBps:3});s.id='preview-session-'+(++sequence);s.recordId='preview-record-'+sequence;s.ownerId=name===user.nickname?user.id:name;s.nickname=name;sessions.set(s.id,s);return s}
function getRecord(id){const s=[...sessions.values()].find(s=>s.recordId===id);if(!s)throw Error('未找到演示记录');return s}
function view(s){return {id:s.id,recordId:s.recordId,nickname:s.nickname,created:s.created,finished:s.finished,...present(s,data)}}
function summary(s){const v=view(s);return {...v,tradeCount:s.trades.length,showcase:published.get(s.recordId)||null}}
for(const [name,percent,start] of [['演示 顺势练习',70,10],['演示 轻仓观察',25,50],[user.nickname,50,90]]){let s=create(name,start);s=act(s,rows.slice(s.start,s.start+500),{type:'targetAdvance',percent,days:20});s=act(s,rows.slice(s.start,s.start+500),{type:'fastForward',days:180});sessions.set(s.id,s);published.set(s.recordId,{id:s.recordId,active:1,share_trades:1,ratings:{demo:4},comments:[{id:'comment-'+s.recordId,nickname:'演示观察者',body:'演示评论：可以结合回撤，再看看加减仓的时机。',created:new Date().toISOString(),self:false}]})}
const initial=create();
window.offlineValues=new Map([['market-session:'+user.id,JSON.stringify(initial.id)]]);
window.offlineStorage={getItem:k=>window.offlineValues.get(k)??null,setItem:(k,v)=>window.offlineValues.set(k,String(v)),removeItem:k=>window.offlineValues.delete(k)};
function showcase(s){const h=published.get(s.recordId),scores=Object.values(h.ratings);return {id:h.id,nickname:s.nickname,self:s.ownerId===user.id,created:s.created,rulesVersion:3,initialDays:300,feeBps:s.feeBps,tradeCount:s.trades.length,metrics:present(s,data).metrics,shareTrades:true,ratingAverage:scores.length?scores.reduce((a,b)=>a+b,0)/scores.length:null,ratingCount:scores.length,myRating:h.ratings[user.id]??null,commentCount:h.comments.length,comments:h.comments,nextCommentOffset:null}}
window.previewAPI=async(url,options={})=>{try{const u=new URL(url,'https://preview.invalid'),p=u.pathname.replace('/api/',''),body=options.body?JSON.parse(options.body):null,token=new Headers(options.headers||{}).get('Authorization')?.replace('Bearer ','');
 if(p==='info')return {stats:{eligibleStocks:1},dataKind:'synthetic'};
 if(p==='account')return {user,admin:false};
 if(p.startsWith('account/'))throw Error('这是离线预览，使用内置演示账户，无需注册或登录。');
 if(p==='session'){if(body)return view(create());const s=sessions.get(token);if(!s)throw Error('请开始一轮演示训练');return view(s)}
 if(p==='action'){let s=sessions.get(token);if(!s)throw Error('演示轮次不存在');if(body.revision!==s.revision)throw Error('进度已更新，请重试');s=act(s,rows.slice(s.start,s.start+500),body);sessions.set(s.id,s);return view(s)}
 if(p==='records'){if(u.searchParams.has('record')){const s=getRecord(u.searchParams.get('record'));return {...view(s),showcase:published.get(s.recordId)||null}}
 const status=u.searchParams.get('status'),version=u.searchParams.get('rulesVersion');return {records:version&&version!=='3'?[]:[...sessions.values()].filter(s=>s.ownerId===user.id&&(!status||(status==='done'?s.done:!s.done))).reverse().map(summary),nextOffset:null}}
 if(p==='showcase/publish'||p==='showcase/withdraw'){const s=getRecord(body.record);if(s.ownerId!==user.id||!s.done)throw Error('只能发布自己已完成的训练');if(p.endsWith('withdraw')){published.get(s.recordId).active=0;return {ok:true}}const h=published.get(s.recordId)||{id:s.recordId,ratings:{},comments:[]};Object.assign(h,{active:1,share_trades:1});published.set(s.recordId,h);return {id:h.id,active:1,share_trades:1}}
 if(p==='showcase'){const id=u.searchParams.get('id');if(id){const s=getRecord(id),h=published.get(id);if(!h?.active)throw Error('这份战绩已撤下');const v=present(s,data);return {...showcase(s),replay:{day:v.day,initialDays:v.initialDays,indicators:v.indicators,candles:v.candles,trades:v.trades}}}
 const sort=u.searchParams.get('sort'),fee=u.searchParams.get('fee'),version=u.searchParams.get('version');let list=[...sessions.values()].filter(s=>published.get(s.recordId)?.active&&(!fee||s.feeBps===Number(fee))&&(!version||version==='3')).map(showcase);list.sort((a,b)=>sort==='drawdown'?a.metrics.drawdown-b.metrics.drawdown:sort==='rating'?(b.ratingAverage??-1)-(a.ratingAverage??-1):sort==='profit'?b.metrics.returnPct-a.metrics.returnPct:sort==='latest'?b.created.localeCompare(a.created):b.metrics.excessPct-a.metrics.excessPct);return {records:list.map((r,i)=>({...r,rank:i+1})),nextOffset:null}}
 if(p==='showcase/rate'){const s=getRecord(body.id),h=published.get(body.id);if(s.ownerId===user.id)throw Error('不能给自己的战绩评分');h.ratings[user.id]=body.score;return showcase(s)}
 if(p==='showcase/comment'){const h=published.get(body.id);if(!body.text.trim()||body.text.length>500)throw Error('评论为 1–500 字');h.comments.unshift({id:'comment-'+(++sequence),nickname:user.nickname,body:body.text.trim(),self:true,created:new Date().toISOString()});return {ok:true}}
 if(p==='showcase/comment/delete'){const h=published.get(body.id);h.comments=h.comments.filter(c=>c.id!==body.comment||!c.self);return {ok:true}}
 if(p==='showcase/challenge'){const original=getRecord(body.id),s=create(user.nickname,original.start);return {recordId:s.recordId}}
 if(p==='pk/public')return {rooms:[],nextOffset:null};if(p==='pk')return {rooms:[]};
 if(p.startsWith('pk/'))throw Error('离线预览不支持多人联机；请在正式网站创建或加入 PK。');
 throw Error('此功能需要联网服务，离线预览暂不提供。');
 }catch(e){return {error:e.message}}};
