import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {createCompatible,act,present,metrics} from '../lib/engine.mjs';
import {sma,ema,calculateIndicators,candleReturn} from '../public/indicators.js';
const createSession=(stock,start,options)=>createCompatible(stock,start,options,2);
const rows=Array.from({length:500},(_,i)=>['2020-01-01',100+i,110+i,90+i,105+i,10000+i]);
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
test('V2 reveals open then close, and hidden OHLCV cannot affect response or indicators',()=>{
  let s=createSession('secret',0,{mode:'test'});assert.equal(s.rulesVersion,2);assert.equal(s.phase,'close');
  s=act(s,rows,{type:'next'});const p=present(s,{code:'secret',rows});assert.equal(p.day,201);assert.equal(p.phase,'open');
  assert.deepEqual(p.candles.at(-1),{day:201,open:300,high:null,low:null,close:null,volume:null,complete:false});
  const changed=structuredClone(rows);changed[200].splice(2,4,99999,1,55555,88888);
  assert.deepEqual(p,present(s,{code:'secret',rows:changed}));
  assert.equal(calculateIndicators(p.candles,p.indicators).count,200);
  s=act(s,rows,{type:'next'});const closed=present(s,{code:'secret',rows});assert.equal(closed.day,201);assert.equal(closed.candles.at(-1).close,305);assert.equal(closed.candles.at(-1).volume,10200);
});
test('both phases execute at the visible price without advancing, and classify four position changes',()=>{
  let s=act(createSession('x',0),rows,{type:'next'});
  for(const a of [{type:'buy',percent:50},{type:'buy',percent:100},{type:'sell',percent:50},{type:'sell',percent:100}])s=act(s,rows,{...a,phase:'close',price:1});
  assert.deepEqual(s.trades.map(t=>t.kind),['open','add','reduce','close']);
  assert.deepEqual(s.trades.map(t=>t.price),[300,300,300,300]);assert.equal(s.day,200);assert.equal(s.phase,'open');
  for(const [i,p] of [50,100,50,0].entries())near(s.trades[i].positionAfter,p);
  for(const [i,p] of [0,50,100,50].entries())near(s.trades[i].positionBefore,p);
  s=act(s,rows,{type:'next'});s=act(s,rows,{type:'buy',percent:50});s=act(s,rows,{type:'sell',percent:100});assert.equal(s.phase,'close');assert.equal(s.day,200);near(s.trades.at(-1).price,305);
});
test('500th open remains tradeable; final close liquidates once with fees and excess return',()=>{
  let s=act(createSession('x',0,{feeBps:3}),rows,{type:'buy',percent:100});
  for(let i=0;i<599;i++)s=act(s,rows,{type:'next'});
  assert.equal(s.day,499);assert.equal(s.phase,'open');assert.equal(s.done,false);
  s=act(s,rows,{type:'sell',percent:50});assert.equal(s.done,false);s=act(s,rows,{type:'next'});
  assert.equal(s.done,true);assert.equal(s.trades.length,3);assert.equal(s.trades.at(-1).forced,true);assert.equal(s.trades.at(-1).price,604);assert.equal(s.shares,0);
  near(s.cash-100000,s.realized);const m=metrics(s,rows);near(m.excessPct,m.returnPct-(604/304-1)*100);assert.throws(()=>act(s,rows,{type:'next'}));
});
test('test-mode indicator changes persist without time advance and reject invalid periods',()=>{
  let s=createSession('x',0,{mode:'test'});const indicators={maPeriods:[3,8,13],macdEnabled:true,fast:4,slow:9,signal:3};
  s=act(s,rows,{type:'indicators',indicators});assert.equal(s.day,199);assert.equal(s.phase,'close');assert.equal(s.indicatorHistory.length,2);assert.equal(s.indicators.macdEnabled,true);assert.equal(s.revision,1);
  for(const p of [{fast:26,slow:12},{maPeriods:[0,3,5]},{signal:1.5},{maPeriods:[3,5]}])assert.throws(()=>act(s,rows,{type:'indicators',indicators:p}));assert.equal(s.revision,1);
});
test('SMA, EMA, MACD and hover returns match hand calculations and ignore incomplete bars',()=>{
  assert.deepEqual(sma([1,2,3,4],3),[null,null,2,3]);assert.deepEqual(ema([1,2,3],3),[1,1.5,2.25]);
  const candles=[{close:10},{close:12},{open:15,close:null,complete:false}];const p={fast:2,slow:3,signal:2};
  const m=calculateIndicators(candles,p);assert.equal(m.count,2);near(m.dif[1],1/3);near(m.dea[1],2/9);near(m.hist[1],2/9);
  assert.equal(candleReturn(candles,0),null);near(candleReturn(candles,1),20);near(candleReturn(candles,2),25);
});
test('version migration tags existing rows V1 without changing stored state or summary bytes',()=>{
  const db=new DatabaseSync(':memory:');try{
    const files=fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(n=>n.endsWith('.sql')).sort();
    for(const n of files.slice(0,2))db.exec(fs.readFileSync(new URL('../drizzle/'+n,import.meta.url),'utf8'));
    const state='{"old":"原始记录", "day":250}',summary='{"original":true}';db.prepare('INSERT INTO training_sessions (id,state,revision,updated,summary) VALUES (?,?,?,?,?)').run('old',state,5,123,summary);
    db.exec(fs.readFileSync(new URL('../drizzle/'+files[2],import.meta.url),'utf8'));
    const r=db.prepare('SELECT * FROM training_sessions').get();assert.equal(r.rules_version,1);assert.equal(r.state,state);assert.equal(r.summary,summary);assert.equal(r.revision,5);
  }finally{db.close()}
});
