import {test} from 'node:test';
import assert from 'node:assert/strict';
import {zoomWindow,attachChartGestures} from '../public/chart-gestures.js';
test('pinch preserves its focal candle and clamps zoom and history boundaries',()=>{
 const view={count:80,end:200};for(const ratio of [0,.3,.5,1]){const next=zoomWindow(view,.5,ratio,300);assert.equal(next.end-next.count*(1-ratio),view.end-view.count*(1-ratio))}
 assert.equal(zoomWindow(view,.001,.5,300).count,15);assert.equal(zoomWindow(view,50,.5,300).count,300);assert.equal(zoomWindow(view,50,.5,300).end,300);
});
test('touch drag, tap inspection, pinch-to-single continuity, cancellation and chart keys do not trade',()=>{
 const canvas={setPointerCapture(){},getBoundingClientRect:()=>({left:0,top:0,width:400})},view={count:80,end:200,hover:null};let draws=0;
 attachChartGestures(canvas,{getView:()=>view,getDays:()=>300,draw:()=>draws++});
 const event=(id,x,y=100,type='pointermove')=>({pointerId:id,clientX:x,clientY:y,pointerType:'touch',type});
 canvas.onpointerdown(event(1,100));canvas.onpointermove(event(1,180));canvas.onpointerup(event(1,180,100,'pointerup'));assert.equal(view.end,180);assert.equal(view.hover,null);
 canvas.onpointerdown(event(1,120));canvas.onpointerup(event(1,120,100,'pointerup'));assert.deepEqual(view.hover,{x:120,y:100});canvas.onpointerleave({pointerType:'touch'});assert.deepEqual(view.hover,{x:120,y:100});
 canvas.onpointerdown(event(1,100));canvas.onpointerdown(event(2,200));canvas.onpointermove(event(2,300));assert.equal(view.count,40);const before=view.end;
 canvas.onpointerup(event(2,300,100,'pointerup'));canvas.onpointermove(event(1,108));assert.equal(view.end,before-1);canvas.onpointercancel(event(1,108,100,'pointercancel'));
 let prevented=false,stopped=false;canvas.onkeydown({key:'ArrowRight',preventDefault(){prevented=true},stopPropagation(){stopped=true}});assert.ok(prevented&&stopped);assert.ok(draws>0);
});
