import assert from 'node:assert/strict';
const base=process.argv[2]||'http://localhost:4173';
let s,cookie;
async function call(path,body){const r=await fetch(base+'/api/'+path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...(s?{authorization:'Bearer '+s.id}:{})},...(body?{body:JSON.stringify(body)}:{})});if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];const d=await r.json();assert.ok(r.ok,JSON.stringify(d));return d}
await call('account/register',{nickname:'QA-'+Date.now(),password:crypto.randomUUID()});
s=await call('session',{mode:'test',feeBps:3});assert.equal(s.candles.length,300);assert.equal(s.reveal,null);
s=await call('action',{type:'buy',percent:100,revision:s.revision});
for(let i=0;i<399;i++)s=await call('action',{type:'next',revision:s.revision});
assert.equal(s.day,500);assert.equal(s.phase,'open');s=await call('action',{type:'sell',percent:50,revision:s.revision});
s=await call('action',{type:'next',revision:s.revision});assert.equal(s.done,true);assert.equal(s.day,500);assert.equal(s.metrics.shares,0);assert.equal(s.candles.length,500);assert.equal(s.trades.at(-1).forced,true);assert.equal(s.trades.at(-1).price,s.candles.at(-1).close);
const restored=await call('session');assert.equal(restored.metrics.equity,s.metrics.equity);
console.log(JSON.stringify({integration:'passed',day:s.day,candles:s.candles.length,autoLiquidated:true,restored:true,stock:s.reveal.code}));
