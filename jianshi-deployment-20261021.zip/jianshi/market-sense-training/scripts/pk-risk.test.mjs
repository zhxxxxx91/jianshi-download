import {test} from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {localDB} from '../lib/local-db.mjs';
import {createStore} from '../lib/store.mjs';
import {handleApi} from '../lib/api.mjs';
import {riskMetrics} from '../lib/risk.mjs';
import {chartWindow} from '../public/chart-layout.js';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
test('fractional zoom/pan and new-day ranges keep full candles and open ticks inside clip',()=>{
  for(const width of [240,720,1200])for(const count of [15,19.7,30.5,80.8,200,499.6])for(const end of [200,200.8,201,202.3,500]){
    const l=chartWindow(500,{count,end},12,width-68),half=Math.max(3,l.step*.65/2);
    assert.equal(l.end-l.start,l.count);assert.ok(Number.isInteger(l.start));assert.ok(l.x(l.start)-half>=12);assert.ok(l.x(l.end-1)+half<=width-68);
    const next=chartWindow(501,{count:l.count,end:501},12,width-68);assert.equal(next.end,501);assert.ok(next.x(500)+Math.max(3,next.step*.65/2)<=width-68);
  }
});
test('annualized risk uses daily close returns with sample deviation and ignores open equity',()=>{
  const s={equity:[{day:200,phase:'close',value:100000},{day:201,phase:'open',value:50000},{day:201,phase:'close',value:110000},{day:202,phase:'open',value:60000},{day:202,phase:'close',value:99000},{day:203,phase:'close',value:108900}]};
  const m=riskMetrics(s),rs=[.1,-.1,.1],mean=rs.reduce((a,b)=>a+b)/3,sd=Math.sqrt(rs.reduce((a,b)=>a+(b-mean)**2,0)/2);
  near(m.sharpe,mean/sd*Math.sqrt(252));near(m.dailyDrawdown,10);near(m.calmar,((1.089)**84-1)/.1);assert.equal(m.riskDays,3);
  assert.deepEqual(m,riskMetrics({equity:s.equity.filter(p=>p.phase==='close')}));
  assert.equal(riskMetrics({equity:[]}).sharpe,null);assert.equal(riskMetrics({equity:[{day:201,value:100000},{day:202,value:100000}]}).calmar,null);assert.equal(riskMetrics({equity:[{day:201,value:90000}]}).calmar,null);
  assert.ok(riskMetrics({equity:[{day:201,value:90000},{day:202,value:80000}]}).calmar<0);
});
const rows=Array.from({length:650},(_,i)=>['SECRET-DATE',10+i/100,11+i/100,9+i/100,10.5+i/100,10000]);
function fixture(){
  const db=localDB(':memory:',path.resolve(import.meta.dirname,'..')),store=createStore(db,{index:async()=>({stocks:[{key:'SECRET-KEY'}]}),stock:async()=>({code:'SECRET-CODE',rows})});
  async function call(route,cookie,body,id){return handleApi(new Request('http://test/api/'+route,{method:body?'POST':'GET',headers:{...(cookie?{cookie}:{}),...(id?{authorization:'Bearer '+id}:{})},...(body?{body:JSON.stringify(body)}:{})}),store,{pepper:'test-pepper-only'})}
  async function register(n){const r=await call('account/register',null,{nickname:n,password:'Test-password-long!'});assert.equal(r.status,200);return r.headers.get('set-cookie').split(';')[0]}
  const data=async(...args)=>{const r=await call(...args);assert.equal(r.status,200,await r.clone().text());return r.json()};return {db,store,call,register,data};
}
test('PK same hidden sample, full-room gate, no host privilege to peers records, and final-only scoreboard',async()=>{
 const f=fixture();try{
  const a=await f.register('房主甲'),b=await f.register('成员乙'),c=await f.register('其他人');
  assert.equal((await f.call('pk')).status,401);assert.equal((await f.call('pk/create',a,{capacity:1})).status,400);
  const room=await f.data('pk/create',a,{capacity:2,feeBps:3}),code=room.code;assert.equal(code.length,8);assert.equal(room.members.length,1);
  assert.equal((await f.call('pk/start',a,{code})).status,409);assert.equal((await f.call('pk?code='+code,c)).status,404);
  let sa=await f.data('records?record='+room.myRecordId,a);assert.equal(sa.pkWaiting,true);assert.equal((await f.call('action',a,{type:'next',revision:0},sa.id)).status,409);
  const rb=await f.data('pk/join',b,{code:code.toLowerCase()});assert.equal(rb.members.length,2);assert.equal((await f.data('pk/join',b,{code})).members.length,2);
  assert.equal((await f.call('pk/join',c,{code})).status,409);assert.equal((await f.call('pk/start',b,{code})).status,403);
  assert.equal((await f.call('records?record='+rb.myRecordId,a)).status,404);assert.equal((await f.call('export?kind=trades&record='+rb.myRecordId,a)).status,404);
  await f.data('pk/start',a,{code});let sb=await f.data('records?record='+rb.myRecordId,b);sa=await f.data('session',a,null,sa.id);
  assert.deepEqual(sa.candles,sb.candles);const rawA=await f.store.read(sa.id),rawB=await f.store.read(sb.id);assert.equal(rawA.start,rawB.start);assert.equal(rawA.stock,rawB.stock);assert.equal(sa.feeBps,sb.feeBps);
  sa=await f.data('action',a,{type:'buy',percent:100,revision:sa.revision},sa.id);
  for(let i=0;i<400;i++)sa=await f.data('action',a,{type:'next',revision:sa.revision},sa.id);
  assert.equal(sa.done,true);assert.equal(sa.reveal,null);assert.ok(Number.isFinite(sa.metrics.sharpe));
  const active=await f.data('pk?code='+code,b);assert.equal(active.status,'active');assert.equal(active.members[0].returnPct,undefined);assert.equal(active.members[0].recordId,undefined);assert.equal(active.members[0].trades,undefined);
  for(const route of ['records','records?record='+room.myRecordId,'export?kind=rounds']){const text=await(await f.call(route,a)).text();assert.ok(!text.includes('SECRET-'))}
  for(let i=0;i<400;i++)sb=await f.data('action',b,{type:'next',revision:sb.revision},sb.id);
  const done=await f.data('pk?code='+code,b);assert.equal(done.status,'done');assert.equal(done.members[0].nickname,'房主甲');assert.equal(done.members[0].rank,1);assert.equal(done.members[1].returnPct,0);assert.equal(done.members[1].sharpe,null);assert.ok(!JSON.stringify(done).includes('SECRET-'));
  const csv=await(await f.call('export?kind=rounds',a)).text();assert.match(csv,/夏普比率/);assert.match(csv,/卡玛比率/);assert.match(csv,new RegExp(code));
 }finally{f.db.close()}
});
test('simultaneous joins cannot overfill a room or create orphan training sessions',async()=>{
 const f=fixture();try{
  const a=await f.register('主账号'),b=await f.register('候选甲'),c=await f.register('候选乙'),room=await f.data('pk/create',a,{capacity:2});
  const results=await Promise.all([f.call('pk/join',b,{code:room.code}),f.call('pk/join',c,{code:room.code})]);assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
  assert.equal((await f.data('pk?code='+room.code,a)).members.length,2);
  assert.equal((await f.db.prepare('SELECT COUNT(*) AS n FROM training_sessions').bind().first()).n,2);
 }finally{f.db.close()}
});
