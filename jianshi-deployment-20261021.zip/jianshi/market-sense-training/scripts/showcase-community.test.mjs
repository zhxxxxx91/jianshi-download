import {test} from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {localDB} from '../lib/local-db.mjs';
import {createStore} from '../lib/store.mjs';
import {handleApi} from '../lib/api.mjs';
const rows=Array.from({length:650},(_,i)=>['PRIVATE-DATE',10+i/100,11+i/100,9+i/100,10.5+i/100,10000]);
test('leaderboard ranks globally, preserves old consent, shares anonymous replay and persists community interactions',async()=>{
 const db=localDB(':memory:',path.resolve(import.meta.dirname,'..')),store=createStore(db,{index:async()=>({stocks:[{key:'PRIVATE-KEY'}]}),stock:async()=>({code:'PRIVATE-CODE',rows})});
 const call=(route,cookie,body,token)=>handleApi(new Request('http://test/api/'+route,{method:body?'POST':'GET',headers:{...(cookie?{cookie}:{}),...(token?{authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})}),store,{pepper:'test-only'});
 const data=async(...args)=>{const r=await call(...args);assert.equal(r.status,200,await r.clone().text());return r.json()};
 const register=async name=>(await call('account/register',null,{nickname:name,password:'long-test-password!'})).headers.get('set-cookie').split(';')[0];
 try{
 const a=await register('作者甲'),b=await register('读者乙'),c=await register('读者丙');
 let s=await data('session',a,{feeBps:3});const token=s.id,record=s.recordId;
 assert.equal((await call('showcase/publish',a,{record,shareTrades:true})).status,400);
 s=await data('action',a,{type:'targetAdvance',percent:70,days:20,revision:s.revision},token);
 while(!s.done)s=await data('action',a,{type:'fastForward',days:30,revision:s.revision},token);
 const published=await data('showcase/publish',a,{record}),id=published.id;
 assert.equal((await data('showcase?id='+id,b)).replay,null);
 assert.equal((await call('showcase/publish',b,{record,shareTrades:true})).status,404);
 await data('showcase/publish',a,{record,shareTrades:true});
 const detail=await data('showcase?id='+id,b);assert.equal(detail.replay.candles.length,500);assert.equal(detail.replay.trades.length,s.trades.length);assert.ok(detail.replay.trades.length>0);
 const text=JSON.stringify(detail);for(const secret of ['PRIVATE-',token,record,'ownerId','cashAfter','recordId'])assert.ok(!text.includes(secret));assert.equal(detail.replay.trades[0].at,undefined);
 assert.equal((await call('showcase/rate',a,{id,score:5})).status,400);
 for(const score of [0,6,2.5,'5',null])assert.equal((await call('showcase/rate',b,{id,score})).status,400);
 await data('showcase/rate',b,{id,score:2});await data('showcase/rate',b,{id,score:4});await data('showcase/rate',c,{id,score:5});
 const rated=await data('showcase?id='+id,b);assert.equal(rated.ratingCount,2);assert.equal(rated.ratingAverage,4.5);assert.equal(rated.myRating,4);
 assert.equal((await call('showcase/comment',b,{id,text:'  '})).status,400);assert.equal((await call('showcase/comment',b,{id,text:'a'.repeat(501)})).status,400);
 await data('showcase/comment',b,{id,text:'<img src=x onerror=alert(1)> 控制回撤不错'});
 const comments=(await data('showcase?id='+id,b)).comments;assert.equal(comments.length,1);assert.equal(comments[0].self,true);
 assert.equal((await call('showcase/comment/delete',c,{id,comment:comments[0].id})).status,404);
 await data('showcase/comment/delete',b,{id,comment:comments[0].id});assert.equal((await data('showcase?id='+id,b)).commentCount,0);
 // Add completed fixtures with known metrics to verify ordering and pagination across all records.
 const original=await store.read(token);
 for(let i=0;i<53;i++){const st={...original,recordId:crypto.randomUUID(),summary:{...original.summary,metrics:{...original.summary.metrics,returnPct:i,excessPct:i,drawdown:i}}};await store.insert(crypto.randomUUID(),st);await store.showcasePublish(crypto.randomUUID(),st.recordId,st.ownerId,true)}
 const first=await data('showcase?sort=excess&version=3&fee=3',b);assert.equal(first.records.length,50);assert.equal(first.records[0].metrics.excessPct,52);assert.equal(first.nextOffset,50);
 const second=await data('showcase?sort=excess&offset=50',b);assert.equal(second.records[0].rank,51);assert.equal(new Set([...first.records,...second.records].map(r=>r.id)).size,54);
 assert.equal((await data('showcase?sort=drawdown',b)).records[0].metrics.drawdown,0);
 assert.equal((await data('showcase?sort=rating',b)).records[0].id,id);
 assert.equal((await data('showcase?fee=0',b)).records.length,0);
 for(const route of ['showcase?sort=bad','showcase?offset=-1','showcase?version=4'])assert.equal((await call(route,b)).status,400);
 await data('showcase/withdraw',a,{record});for(const route of ['showcase?id='+id])assert.equal((await call(route,b)).status,404);
 for(const [route,body] of [['rate',{id,score:3}],['comment',{id,text:'hello'}],['challenge',{id}]])assert.equal((await call('showcase/'+route,b,body)).status,404);
 assert.equal((await call('showcase')).status,401);
 }finally{db.close()}
});
