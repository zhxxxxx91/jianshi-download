import fs from 'node:fs/promises';
import path from 'node:path';
const config=JSON.parse(await new Promise(resolve=>{let input='';if(process.stdin.isTTY)process.stdin.setRawMode(true);console.log('Ready for upload JSON on stdin (hidden).');process.stdin.setEncoding('utf8');const read=c=>{input+=c;if(/[\r\n]/.test(input)){process.stdin.off('data',read);if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();resolve(input)}};process.stdin.on('data',read);process.stdin.resume()}));
const root=path.resolve(import.meta.dirname,'../work/corpus'),index=JSON.parse(await fs.readFile(path.join(root,'index.json'),'utf8'));
let complete=0;const entries=index.stocks.map(s=>s.key+'.json.gz'),jobs=[];
for(let i=0;i<entries.length;i+=20)jobs.push(entries.slice(i,i+20));
async function upload(names){const files=await Promise.all(names.map(async key=>({key,data:(await fs.readFile(path.join(root,key))).toString('base64')})));for(let attempt=0;attempt<4;attempt++){try{const r=await fetch(config.url+'/api/import',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+config.key,...(config.bypass?{'OAI-Sites-Authorization':'Bearer '+config.bypass}:{})},body:JSON.stringify({files}),signal:AbortSignal.timeout(120000)});if(!r.ok)throw Error('Upload HTTP '+r.status);complete+=names.length;if(complete%200<20)console.log('Imported '+complete+' / '+entries.length);return}catch(e){if(attempt===3)throw e;await new Promise(r=>setTimeout(r,1000*(attempt+1)))}}}
await Promise.all(Array.from({length:5},async()=>{while(jobs.length)await upload(jobs.shift())}));
await upload(['index.json']);console.log('Complete: '+entries.length+' stocks, index committed last.');
