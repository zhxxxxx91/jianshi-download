import {test} from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {localDB} from '../lib/local-db.mjs';
import {createStore} from '../lib/store.mjs';
import {handleApi} from '../lib/api.mjs';
import {csvRow} from '../lib/records.mjs';
import {summarize} from '../lib/records.mjs';
import * as legacy from '../lib/engine-v1.mjs';
const root=path.resolve(import.meta.dirname,'..');
const rows=Array.from({length:650},(_,i)=>['2020-01-01',10+i/100,11+i/100,9+i/100,10+i/100,10000]);
function fixture(){
  const db=localDB(':memory:',root),store=createStore(db,{index:async()=>({stocks:[{key:'stock'}],stats:{eligibleStocks:1}}),stock:async()=>({code:'hidden-code',adjust:'2',rows})});
  const config={pepper:'test-only-pepper-random-is-used-in-production',ownerEmail:'owner@example.test'};
  async function call(route,{body,cookie,id,headers={}}={}){return handleApi(new Request('https://test.local/api/'+route,{method:body?'POST':'GET',headers:{...(cookie?{cookie}:{}),...(id?{authorization:'Bearer '+id}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})}),store,config)}
  async function register(name){const r=await call('account/register',{body:{nickname:name,password:'Example-long-pass!'}});assert.equal(r.status,200,await r.clone().text());assert.match(r.headers.get('set-cookie'),/HttpOnly; SameSite=Strict.*Secure/);return {cookie:r.headers.get('set-cookie').split(';')[0],user:(await r.json()).user}}
  return {db,store,call,register};
}
test('V1 and V3 can be filtered and exported separately without rewriting legacy records',async()=>{
  const f=fixture();try{
    const a=await f.register('版本检查'),b=await f.register('隔离检查');
    let old=legacy.act(legacy.createSession('stock',0),rows,{type:'buy',percent:50});old.ownerId=a.user.id;old.recordId='legacy-record';
    old.summary=summarize(old,{code:'hidden-code',rows});delete old.summary.rulesVersion;delete old.summary.metrics.excessPct;
    await f.store.insert('a'.repeat(68),old);const before=JSON.stringify(await f.store.read('a'.repeat(68)));
    let modern=await(await f.call('session',{cookie:a.cookie,body:{rulesVersion:1}})).json();assert.equal(modern.rulesVersion,3);
    modern=await(await f.call('action',{cookie:a.cookie,id:modern.id,body:{type:'next',revision:modern.revision}})).json();
    await f.call('action',{cookie:a.cookie,id:modern.id,body:{type:'buy',percent:50,revision:modern.revision}});
    const owner={'oai-authenticated-user-id':'owner','oai-authenticated-user-email':'owner@example.test'};
    for(const version of [1,3]){
      for(const [prefix,auth]of [['',{cookie:a.cookie}],['admin/',{headers:owner}]]){
        const list=await(await f.call(prefix+'records?rulesVersion='+version,auth)).json();assert.equal(list.records.length,1);assert.equal(list.records[0].rulesVersion,version);assert.equal(typeof list.records[0].metrics.excessPct,'number');
        const csv=await(await f.call(prefix+'export?kind=trades&rulesVersion='+version,auth)).text();assert.equal(csv.trim().split('\r\n').length,2);assert.match(csv,new RegExp('V'+version));assert.match(csv,/建仓/);assert.match(csv,/成交前仓位/);assert.match(csv,version===3?/开盘/:/收盘/);
      }
      assert.equal((await(await f.call('records?rulesVersion='+version,{cookie:b.cookie})).json()).records.length,0);
    }
    const detail=await(await f.call('records?record=legacy-record',{cookie:a.cookie})).json();assert.equal(detail.rulesVersion,1);assert.equal(detail.trades[0].kind,'open');assert.equal(JSON.stringify(await f.store.read('a'.repeat(68))),before);
    const resumed=await(await f.call('action',{cookie:a.cookie,id:'a'.repeat(68),body:{type:'sell',percent:50,revision:old.revision}})).json();assert.equal(resumed.day,201);assert.equal(resumed.rulesVersion,1);
    assert.equal((await f.call('records?rulesVersion=4',{cookie:a.cookie})).status,400);
  }finally{f.db.close()}
});
test('register / login uses normalized unique nickname, hashed password and server cookie; logout invalidates token',async()=>{
  const f=fixture();try{const a=await f.register('Alice');const stored=await f.store.userByName('alice');assert.notEqual(stored.password_hash,'Example-long-pass!');assert.equal(stored.password_hash.length,64);
    assert.equal((await f.call('account/register',{body:{nickname:'ＡＬＩＣＥ',password:'Another-long-password'}})).status,409);
    assert.equal((await f.call('account/login',{body:{nickname:'alice',password:'Wrong-password'}})).status,401);
    const login=await f.call('account/login',{body:{nickname:'ALICE',password:'Example-long-pass!'}});assert.equal(login.status,200);
    assert.equal((await(await f.call('account',{cookie:a.cookie})).json()).user.id,a.user.id);
    await f.call('account/logout',{cookie:a.cookie,body:{}});assert.equal((await(await f.call('account',{cookie:a.cookie})).json()).user,null);
  }finally{f.db.close()}
});
test('participants cannot list, read, export or mutate another user even with leaked training token; admin has read-only cross-user records',async()=>{
  const f=fixture();try{const a=await f.register('甲同学'),b=await f.register('乙同学');let s=await(await f.call('session',{cookie:a.cookie,body:{ownerId:b.user.id}})).json();
    s=await(await f.call('action',{cookie:a.cookie,id:s.id,body:{type:'buy',percent:50,revision:0}})).json();
    const list=await(await f.call('records',{cookie:a.cookie})).json(),record=list.records[0].recordId;
    assert.equal(list.records.length,1);assert.equal(list.records[0].tradeCount,1);assert.equal(JSON.stringify(list).includes('hidden-code'),false);
    assert.equal((await f.call('records')).status,401);assert.equal((await(await f.call('records?ownerId='+a.user.id,{cookie:b.cookie})).json()).records.length,0);
    for(const route of ['records?record='+record,'export?kind=trades&record='+record])assert.equal((await f.call(route,{cookie:b.cookie})).status,404);
    assert.equal((await f.call('session',{cookie:b.cookie,id:s.id})).status,404);
    assert.equal((await f.call('action',{cookie:b.cookie,id:s.id,body:{type:'next',revision:s.revision}})).status,404);
    assert.equal((await f.call('admin/records',{cookie:a.cookie,headers:{'x-admin':'true'}})).status,403);
    assert.equal((await f.call('admin/export?kind=trades',{cookie:a.cookie})).status,403);
    const owner={'oai-authenticated-user-id':'owner-site-id','oai-authenticated-user-email':'owner@example.test'};
    assert.equal((await(await f.call('admin/records',{headers:owner})).json()).records.length,1);
    const detail=await(await f.call('admin/records?record='+record,{headers:owner})).json();assert.equal(detail.id,undefined);assert.equal(detail.trades.length,1);assert.equal(detail.reveal,null);
    assert.equal((await f.call('action',{headers:owner,id:s.id,body:{type:'next',revision:s.revision}})).status,401);
    const csv=await(await f.call('admin/export?kind=trades',{headers:owner})).text();assert.match(csv,/甲同学/);assert.match(csv,/买入/);assert.equal(csv.includes(s.id),false);
  }finally{f.db.close()}
});
test('entire 500-day round persists all fills, auto-liquidation, summary and resumes across independent login; stale revision is rejected',async()=>{
  const f=fixture();try{const a=await f.register('完整测试');let s=await(await f.call('session',{cookie:a.cookie,body:{mode:'test',feeBps:3}})).json();assert.equal(s.day,300);
    s=await(await f.call('action',{cookie:a.cookie,id:s.id,body:{type:'buy',percent:100,revision:0}})).json();assert.equal((await f.call('action',{cookie:a.cookie,id:s.id,body:{type:'buy',percent:100,revision:0}})).status,409);
    for(let i=0;i<399;i++){const r=await f.call('action',{cookie:a.cookie,id:s.id,body:{type:'next',revision:s.revision}});assert.equal(r.status,200);s=await r.json()}
    s=await(await f.call('action',{cookie:a.cookie,id:s.id,body:{type:'sell',percent:50,revision:s.revision}})).json();assert.equal(s.day,500);assert.equal(s.phase,'open');assert.equal(s.done,false);s=await(await f.call('action',{cookie:a.cookie,id:s.id,body:{type:'next',revision:s.revision}})).json();assert.equal(s.done,true);assert.equal(s.metrics.shares,0);assert.equal(s.trades.length,3);assert.equal(s.trades.at(-1).forced,true);
    const login=await f.call('account/login',{body:{nickname:'完整测试',password:'Example-long-pass!'}}),cookie=login.headers.get('set-cookie').split(';')[0];
    const list=await(await f.call('records?status=done',{cookie})).json();assert.equal(list.records.length,1);assert.equal(list.records[0].tradeCount,3);assert.equal(list.records[0].metrics.equity,s.metrics.equity);
    const r=await(await f.call('records?record='+list.records[0].recordId,{cookie})).json();assert.deepEqual(r.trades,s.trades);assert.equal(r.id,s.id);assert.equal(r.candles.length,500);
    const csv=await(await f.call('export?kind=trades',{cookie})).text();assert.equal(csv.trim().split('\r\n').length,4);assert.match(csv,/是/);
  }finally{f.db.close()}
});
test('record lists paginate, complete CSV export spans all pages and nickname filters are bound literal values',async()=>{
  const f=fixture();try{const a=await f.register('Pagination');for(let i=0;i<53;i++)assert.equal((await f.call('session',{cookie:a.cookie,body:{}})).status,200);
    const one=await(await f.call('records',{cookie:a.cookie})).json();assert.equal(one.records.length,50);assert.equal(one.nextOffset,50);
    assert.equal((await(await f.call('records?offset=50',{cookie:a.cookie})).json()).records.length,3);
    const csv=await(await f.call('export?kind=rounds',{cookie:a.cookie})).text();assert.equal(csv.trim().split('\r\n').length,54);
    const owner={'oai-authenticated-user-id':'owner','oai-authenticated-user-email':'owner@example.test'};
    assert.equal((await(await f.call('admin/records?nickname=%25',{headers:owner})).json()).records.length,0);
    assert.equal((await(await f.call('admin/records?nickname=agina',{headers:owner})).json()).records.length,50);
  }finally{f.db.close()}
});
test('cross-site writes rejected; password change invalidates all sessions; login attempts rate limited',async()=>{
  const f=fixture();try{assert.equal((await f.call('account/register',{body:{nickname:'CSRF',password:'Example-long-pass!'},headers:{origin:'https://evil.test'}})).status,403);
    const a=await f.register('安全测试');assert.equal((await f.call('account/password',{cookie:a.cookie,body:{currentPassword:'Example-long-pass!',password:'Changed-long-pass!'}})).status,200);
    assert.equal((await(await f.call('account',{cookie:a.cookie})).json()).user,null);
    assert.equal((await f.call('account/login',{body:{nickname:'安全测试',password:'Changed-long-pass!'}})).status,200);
    let r;for(let i=0;i<14;i++)r=await f.call('account/login',{body:{nickname:'安全测试',password:'Invalid-password!'}});assert.equal(r.status,429);
    assert.match(csvRow(['=SUM(1,2)','@test','-text',-3]),/^"'=SUM/);
  }finally{f.db.close()}
});
