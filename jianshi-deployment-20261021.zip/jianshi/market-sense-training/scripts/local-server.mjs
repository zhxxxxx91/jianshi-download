import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {gunzipSync} from 'node:zlib';
import {handleApi} from '../lib/api.mjs';
import {createStore} from '../lib/store.mjs';
import {localDB} from '../lib/local-db.mjs';
import {randomBytes} from 'node:crypto';
const root=path.resolve(import.meta.dirname,'..'),corpus=path.join(root,'work/corpus'),sessions=path.join(root,'work/sessions');
await fs.mkdir(sessions,{recursive:true});
const cache=new Map();
const pepperPath=path.join(root,'work/local-account-pepper');
let pepper;try{pepper=await fs.readFile(pepperPath,'utf8')}catch{pepper=randomBytes(32).toString('hex');await fs.writeFile(pepperPath,pepper,{mode:0o600})}
const storage=createStore(localDB(path.join(root,'work/accounts.sqlite'),root),{
  index:()=>fs.readFile(path.join(corpus,'index.json'),'utf8').then(JSON.parse),
  async stock(key){if(!cache.has(key)){if(cache.size>20)cache.delete(cache.keys().next().value);cache.set(key,JSON.parse(gunzipSync(await fs.readFile(path.join(corpus,key+'.json.gz')))))}return cache.get(key)}
});
const server=http.createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://'+req.headers.host);
  if(url.pathname.startsWith('/api/')){
    const chunks=[];let size=0;for await(const c of req){size+=c.length;if(size>10000){res.writeHead(413);res.end();return}chunks.push(c)}
    const cleanHeaders={...req.headers};delete cleanHeaders['oai-authenticated-user-id'];delete cleanHeaders['oai-authenticated-user-email'];
    const request=new Request(url,{method:req.method,headers:cleanHeaders,...(req.method!=='GET'?{body:Buffer.concat(chunks)}:{})});
    const response=await handleApi(request,storage,{pepper});res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
  }
  const name=url.pathname==='/'?'trainer.html':url.pathname.slice(1);
  if(!['mobile-preview.html','trainer.html','trainer.js','trainer.css','studio.css','studio.js','theme.js','site-pages.css','navigation.css','layout-preview.js','layout-preview.css','layout-balanced.css','favicon.svg','account-ui.js','accounts.css','records.html','records.js','admin.html','indicators.js','chart.js','training-v2.css','chart-layout.js','chart-gestures.js','mobile-studio.css','pk.html','pk.js','pk.css','pk-watch.html','pk-watch.js','pk-watch-chart.js','pk-public.js','showcase.html','showcase.js','showcase.css','state-patch.js'].includes(name)){res.writeHead(404);res.end();return}
  let content=await fs.readFile(path.join(root,'public',name));
  if(name==='trainer.html'){const index=await storage.index().catch(()=>({}));if(index.source?.startsWith('Synthetic'))content=Buffer.from(content.toString().replace('真实日线 · 匿名标的 · 无未来数据','本地合成行情 · 仅供界面与功能验证').replace('正在连接历史行情…','正在连接本地演示行情…').replace('<footer><span>','<footer><span>本地演示 · 合成行情 &nbsp; '));}res.writeHead(200,{'Content-Type':name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/javascript; charset=utf-8'});res.end(content);
}catch(e){res.writeHead(500);res.end('Server error')}});
server.listen(Number(process.env.PORT||4173),'0.0.0.0',()=>console.log('Local: http://localhost:'+ (process.env.PORT||4173)));
