import {test} from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {localDB} from '../lib/local-db.mjs';
import {createStore} from '../lib/store.mjs';
import {handleApi} from '../lib/api.mjs';
const root=path.resolve(import.meta.dirname,'..'),rows=Array.from({length:550},(_,i)=>['SECRET-DATE',100+i/10,103+i/10,97+i/10,100+i/10+Math.sin(i),10000+i]);
function fixture(){const db=localDB(':memory:',root),store=createStore(db,{index:async()=>({stocks:[{key:'SECRET-STOCK'}]}),stock:async()=>({code:'SECRET-CODE',rows})});
 async function call(route,cookie,body,id){return handleApi(new Request('http://test/api/'+route,{method:body?'POST':'GET',headers:{...(cookie?{cookie}:{}),...(id?{authorization:'Bearer '+id}:{})},...(body?{body:JSON.stringify(body)}:{})}),store,{pepper:'only-a-test-pepper'})}
 async function ok(...args){const r=await call(...args);assert.equal(r.status,200,await r.clone().text());assert.equal(r.headers.get('cache-control'),'no-store');return r.json()}
 async function user(n){const r=await call('account/register',null,{nickname:n,password:'Test-only-password!'});assert.equal(r.status,200);return r.headers.get('set-cookie').split(';')[0]}return {db,store,call,ok,user};}
test('private is default, invalid types rejected, anonymous public list excludes private rooms and all watch paths deny access',async()=>{
 const f=fixture();try{const a=await f.user('私密房主'),b=await f.user('私密成员'),outside=await f.user('观众');
 assert.equal((await f.call('pk/create',null,{capacity:2,visibility:'public'})).status,401);assert.equal((await f.call('pk/create',a,{capacity:2,visibility:'oops'})).status,400);
 const r=await f.ok('pk/create',a,{capacity:2});assert.equal(r.visibility,'private');assert.equal((await f.ok('pk/public')).rooms.length,0);
 const rb=await f.ok('pk/join',b,{code:r.code});assert.equal(rb.visibility,'private');await f.ok('pk/start',a,{code:r.code});
 for(const u of [a,b]){const v=await f.ok('pk?code='+r.code,u),s=await f.ok('records?record='+v.myRecordId,u);await f.ok('action',u,{type:'fastForward',days:200,revision:s.revision},s.id)}
 for(const cookie of [null,outside,a])for(const route of ['pk/watch?code='+r.code,'pk/watch/trades?code='+r.code+'&record='+rb.myRecordId,'pk/watch/chart?code='+r.code+'&record='+rb.myRecordId]){const response=await f.call(route,cookie);assert.equal(response.status,404);assert.ok(!(await response.text()).includes('私密成员'))}
 assert.equal((await f.ok('pk/public')).rooms.length,0);assert.equal((await f.call('pk/visibility',a,{code:r.code,visibility:'public'})).status,404);assert.equal((await f.store.pkRoom(r.code)).visibility,'private');
 assert.equal((await f.call('pk/watch',null,{})).status,405);assert.equal((await f.call('pk/public?offset=-1')).status,400);
 }finally{f.db.close()}
});
test('public room joining requires explicit notice acceptance and spectators never consume a seat or gain trading authority',async()=>{
 const f=fixture();try{const a=await f.user('公开房主'),b=await f.user('公开成员'),c=await f.user('第三人'),r=await f.ok('pk/create',a,{capacity:2,visibility:'public'});
 assert.equal(r.visibility,'public');assert.equal((await f.ok('pk/preview?code='+r.code,b)).visibility,'public');assert.equal((await f.call('pk/join',b,{code:r.code})).status,409);assert.equal((await f.call('pk/join',b,{code:r.code,acceptPublic:'true'})).status,409);assert.equal((await f.store.pkMembers(r.code)).length,1);
 const directory=await f.ok('pk/public');assert.equal(directory.rooms.length,1);assert.equal(directory.rooms[0].hostNickname,'公开房主');
 for(let i=0;i<3;i++){const watch=await f.ok('pk/watch?code='+r.code);assert.equal(watch.status,'waiting');assert.equal(watch.members.length,1);assert.equal(watch.members[0].tradeCount,0)}
 assert.equal((await f.store.pkMembers(r.code)).length,1);const rb=await f.ok('pk/join',b,{code:r.code,acceptPublic:true});assert.equal(rb.members.length,2);assert.equal((await f.call('pk/start',c,{code:r.code})).status,403);assert.equal((await f.call('pk/consent',c,{code:r.code,agree:true})).status,404);
 const sa=await f.ok('records?record='+r.myRecordId,a);assert.equal((await f.call('action',c,{type:'target',percent:100,revision:0},sa.id)).status,404);assert.equal((await f.call('records?record='+r.myRecordId,c)).status,404);assert.equal((await f.call('export?kind=trades&record='+r.myRecordId,c)).status,404);
 }finally{f.db.close()}
});
test('live public projections track opens, target fills and fast forward, expose no hidden corpus or session fields, and scope trade history to the room',async()=>{
 const f=fixture();try{const a=await f.user('实时甲'),b=await f.user('实时乙'),room=await f.ok('pk/create',a,{capacity:2,visibility:'public'}),code=room.code;await f.ok('pk/join',b,{code,acceptPublic:true});await f.ok('pk/start',a,{code});let s=await f.ok('records?record='+room.myRecordId,a);
 const privateRoom=await f.ok('pk/create',a,{capacity:2});assert.equal((await f.call('pk/watch/trades?code='+code+'&record='+privateRoom.myRecordId)).status,404);
 s=await f.ok('action',a,{type:'next',revision:s.revision},s.id);s=await f.ok('action',a,{type:'target',percent:65,revision:s.revision},s.id);
 let watch=await f.ok('pk/watch?code='+code),m=watch.members.find(m=>m.recordId===room.myRecordId);assert.equal(m.phase,'open');assert.equal(m.day,301);assert.equal(m.metrics.position,65);assert.equal(m.metrics.equity,s.metrics.equity);assert.equal(m.recentTrades[0].phase,'open');assert.equal(m.recentTrades[0].kind,'open');
 const text=JSON.stringify(watch);for(const secret of ['SECRET-',s.id,'ownerId','salt','password','stock','candles','high','low','volume'])assert.ok(!text.includes(secret),secret);
 for(let i=0;i<104;i++)s=await f.ok('action',a,{type:'target',percent:i%2?65:35,revision:s.revision},s.id);
 const trades=await f.ok('pk/watch/trades?code='+code+'&record='+room.myRecordId);assert.equal(trades.trades.length,100);assert.equal(trades.nextOffset,100);assert.equal(trades.trades[0].sequence,105);const older=await f.ok('pk/watch/trades?code='+code+'&record='+room.myRecordId+'&offset=100');assert.equal(older.trades.length,5);assert.equal(older.nextOffset,null);
 s=await f.ok('action',a,{type:'fastForward',days:200,revision:s.revision},s.id);watch=await f.ok('pk/watch?code='+code);assert.equal(watch.status,'active');m=watch.members.find(m=>m.recordId===room.myRecordId);assert.equal(m.done,true);assert.equal(m.metrics.position,0);assert.equal(m.recentTrades[0].forced,true);
 const rb=await f.ok('pk?code='+code,b),sb=await f.ok('records?record='+rb.myRecordId,b);await f.ok('action',b,{type:'fastForward',days:200,revision:sb.revision},sb.id);assert.equal((await f.ok('pk/watch?code='+code)).status,'done');assert.equal((await f.ok('pk/public')).rooms[0].status,'done');
 }finally{f.db.close()}
});
test('spectator candles mirror each participant, mask unfinished bars, retain trade markers and indicator settings',async()=>{
 const f=fixture();try{
  const a=await f.user('图表甲'),b=await f.user('图表乙'),room=await f.ok('pk/create',a,{capacity:2,visibility:'public'}),code=room.code,other=await f.ok('pk/join',b,{code,acceptPublic:true});await f.ok('pk/start',a,{code});
  const path='pk/watch/chart?code='+code+'&record='+room.myRecordId;
  let s=await f.ok('records?record='+room.myRecordId,a),chart=await f.ok(path);assert.deepEqual(chart.candles,s.candles);assert.equal(chart.candles.length,300);
  s=await f.ok('action',a,{type:'next',revision:s.revision},s.id);s=await f.ok('action',a,{type:'target',percent:65,revision:s.revision},s.id);
  s=await f.ok('action',a,{type:'indicators',indicators:{maPeriods:[7,21,50],macdEnabled:true,fast:6,slow:19,signal:5},revision:s.revision},s.id);
  chart=await f.ok(path);assert.deepEqual(chart.candles,s.candles);assert.equal(chart.candles.length,301);assert.deepEqual(chart.candles.at(-1),{day:301,open:s.candles.at(-1).open,high:null,low:null,close:null,volume:null,complete:false});assert.deepEqual(chart.indicators,s.indicators);assert.equal(chart.trades[0].kind,'open');assert.equal(chart.trades[0].positionAfter,65);assert.equal(chart.revision,s.revision);
  const peer=await f.ok('pk/watch/chart?code='+code+'&record='+other.myRecordId);assert.equal(peer.candles.length,300);assert.equal(peer.trades.length,0);
  for(const secret of ['SECRET-',s.id,'ownerId','stock','reveal','start','indicatorHistory'])assert.ok(!JSON.stringify(chart).includes(secret),secret);
  s=await f.ok('action',a,{type:'next',revision:s.revision},s.id);chart=await f.ok(path);assert.deepEqual(chart.candles,s.candles);assert.equal(chart.candles.at(-1).complete,true);assert.ok(chart.candles.at(-1).volume>0);
  const privateRoom=await f.ok('pk/create',a,{capacity:2});assert.equal((await f.call('pk/watch/chart?code='+code+'&record='+privateRoom.myRecordId)).status,404);assert.equal((await f.call('pk/watch/chart?code='+code+'&record='+room.myRecordId,null,{})).status,405);
  s=await f.ok('action',a,{type:'fastForward',days:200,revision:s.revision},s.id);chart=await f.ok(path);assert.equal(chart.done,true);assert.equal(chart.candles.length,500);assert.deepEqual(chart.candles,s.candles);assert.equal(chart.trades.at(-1).forced,true);assert.ok(!JSON.stringify(chart).includes('SECRET-'));
 }finally{f.db.close()}
});
test('migration preserves old room data and makes every existing room private',()=>{
 const db=new DatabaseSync(':memory:');try{const files=fs.readdirSync(path.join(root,'drizzle')).filter(f=>f.endsWith('.sql')).sort();for(const f of files.slice(0,5))db.exec(fs.readFileSync(path.join(root,'drizzle',f),'utf8'));
 db.prepare('INSERT INTO participant_accounts(id,nickname,nickname_key,salt,password_hash,created) VALUES (?,?,?,?,?,?)').run('old-owner','Old','old','test-salt','test-hash',1);
 db.prepare('INSERT INTO pk_rooms(code,owner_id,capacity,stock,start,fee_bps,created,rules_version,started_size) VALUES (?,?,?,?,?,?,?,?,?)').run('OLDROOM','old-owner',4,'old-stock',7,3,'original-time',3,2);const before=db.prepare('SELECT * FROM pk_rooms').get();db.exec(fs.readFileSync(path.join(root,'drizzle',files[5]),'utf8'));const after=db.prepare('SELECT * FROM pk_rooms').get();assert.equal(after.visibility,'private');delete after.visibility;assert.deepEqual(after,before);
 }finally{db.close()}
});
