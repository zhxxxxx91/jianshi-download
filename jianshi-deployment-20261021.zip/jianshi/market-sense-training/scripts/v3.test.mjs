import {test} from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {createSession,createCompatible,act,present,metrics} from '../lib/engine.mjs';
import {cachedCorpus} from '../lib/corpus-cache.mjs';
import {compactState} from '../lib/state-patch.mjs';
import {mergeState} from '../public/state-patch.js';
import {riskMetrics} from '../lib/risk.mjs';
import {localDB} from '../lib/local-db.mjs';
import {createStore} from '../lib/store.mjs';
import {handleApi} from '../lib/api.mjs';
import {summarize} from '../lib/records.mjs';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`),rows=Array.from({length:550},(_,i)=>['SECRET-DATE',100+i/10,103+i/10,97+i/10,100+i/10+Math.sin(i)*2,10000+i]),data={code:'SECRET-CODE',rows};
test('V3 300+200 target positions include fees; hidden prices do not leak; fast forward equals all daily steps',()=>{
 let s=createSession('stock',0,{feeBps:3});assert.equal(present(s,data).candles.length,300);
 for(const target of [25,75,30,100,0]){s=act(s,rows,{type:'target',percent:target});near(metrics(s,rows).position,target)}
 assert.deepEqual(s.trades.map(t=>t.kind),['open','add','reduce','add','close']);
 s=act(s,rows,{type:'next'});const hidden=structuredClone(rows);hidden[300].splice(2,4,999,0,888,777);assert.deepEqual(present(s,data),present(s,{...data,rows:hidden}));
 s=act(s,rows,{type:'target',percent:60});let manual=s;for(let i=0;i<41;i++)manual=act(manual,rows,{type:'next'});const fast=act(s,rows,{type:'fastForward',days:20});assert.equal(fast.day,320);assert.equal(fast.phase,'close');assert.deepEqual(fast.equity,manual.equity);assert.deepEqual(metrics(fast,rows),metrics(manual,rows));
 const done=act(fast,rows,{type:'fastForward',days:200});assert.equal(done.done,true);assert.equal(done.day,499);assert.equal(done.shares,0);assert.equal(done.trades.at(-1).forced,true);assert.equal(metrics(done,rows).riskDays,200);
 for(const days of [0,-1,1.5,201])assert.throws(()=>act(s,rows,{type:'fastForward',days}));
});
test('delta responses merge to exact full state across open, close, trade, indicators and fast forward with substantially smaller next-step payload',()=>{
 let s=createSession('stock',0),client={id:'test',...present(s,data)};
 for(const a of [{type:'next'},{type:'target',percent:50},{type:'next'},{type:'indicators',indicators:{macdEnabled:true}},{type:'fastForward',days:20},{type:'fastForward',days:200}]){
  const next=act(s,rows,a),full={id:'test',...present(next,data)},delta=compactState('test',s,present(next,data));client=mergeState(client,delta);assert.deepEqual(client,full);
  if(a.type==='next')assert.ok(JSON.stringify(delta).length<JSON.stringify(full).length*.2);s=next;
 }
 assert.throws(()=>mergeState({id:'wrong',revision:0},compactState('test',s,present(s,data))));
});
test('bounded corpus cache coalesces simultaneous loads, evicts and retries failures',async()=>{
 let calls=0,indices=0;const c=cachedCorpus({index:async()=>{indices++;return {}},stock:async key=>{calls++;if(key==='fail')throw Error('fail');return {key}}},{limit:2});
 const [a,b]=await Promise.all([c.stock('a'),c.stock('a')]);assert.equal(a,b);assert.equal(calls,1);await Promise.all([c.index(),c.index()]);assert.equal(indices,1);
 await c.stock('b');await c.stock('c');await c.stock('a');assert.equal(calls,4);await assert.rejects(c.stock('fail'));await assert.rejects(c.stock('fail'));assert.equal(calls,6);
});
test('excess ratios match independent daily active-return and relative-wealth calculations',()=>{
 const prices=[100,110,99,108.9],values=[100000,105000,94500,103950],s={rulesVersion:3,benchmarkBase:100,equity:values.map((value,i)=>({day:300+i,phase:'close',value,price:prices[i]}))},m=riskMetrics(s);
 const active=[.05-.1,-.1-(-.1),.1-.1],mean=active.reduce((a,b)=>a+b)/3,sd=Math.sqrt(active.reduce((a,r)=>a+(r-mean)**2,0)/2);near(m.excessSharpe,mean/sd*Math.sqrt(252));
 const rel=1.0395/1.089,dd=1-rel;near(m.excessCalmar,(rel**84-1)/dd);near(m.relativeDrawdown,dd*100);assert.equal(m.riskDays,3);
 const hold={...s,equity:prices.map((p,i)=>({day:300+i,value:p*1000,price:p}))};assert.equal(riskMetrics(hold).excessSharpe,null);assert.equal(riskMetrics(hold).excessCalmar,null);
});
function fixture(){const db=localDB(':memory:',path.resolve(import.meta.dirname,'..')),store=createStore(db,{index:async()=>({stocks:[{key:'stock'}]}),stock:async()=>data});
 async function call(route,cookie,body,id){return handleApi(new Request('http://test/api/'+route,{method:body?'POST':'GET',headers:{...(cookie?{cookie}:{}),...(id?{authorization:'Bearer '+id}:{})},...(body?{body:JSON.stringify(body)}:{})}),store,{pepper:'local-test-only'})}
 async function ok(...args){const r=await call(...args);assert.equal(r.status,200,await r.clone().text());return r.json()}
 async function user(n){const r=await call('account/register',null,{nickname:n,password:'Testing-only-password!'});assert.equal(r.status,200);return r.headers.get('set-cookie').split(';')[0]}return {db,store,call,ok,user};}
test('showcase opt-in, ownership, finished-training gate, anonymous exact-sample challenges and withdrawal',async()=>{
 const f=fixture();try{const a=await f.user('战绩甲'),b=await f.user('挑战乙');let s=await f.ok('session',a,{mode:'training',feeBps:3});const r=(await f.ok('records',a)).records[0].recordId;
 assert.equal((await f.ok('showcase',b)).records.length,0);assert.equal((await f.call('showcase/publish',a,{record:r})).status,400);assert.equal((await f.call('showcase/publish',b,{record:r})).status,404);
 s=await f.ok('action',a,{type:'target',percent:70,revision:s.revision},s.id);s=await f.ok('action',a,{type:'fastForward',days:200,revision:s.revision},s.id);assert.equal(s.done,true);
 assert.equal((await f.ok('showcase',b)).records.length,0,'completed training stays private until explicitly published');assert.equal((await f.ok('session',a,undefined,s.id)).recordId,r);
 const pub=await f.ok('showcase/publish',a,{record:r}),list=await f.ok('showcase',b);assert.equal(list.records.length,1);for(const secret of ['SECRET-','candles','trades','stock','start','recordId'])assert.ok(!JSON.stringify(list).includes(secret));
 const challenge=await f.ok('showcase/challenge',b,{id:pub.id}),challenger=await f.ok('records?record='+challenge.recordId,b),original=await f.store.read(s.id),fresh=await f.store.read(challenger.id);assert.equal(fresh.start,original.start);assert.equal(fresh.stock,original.stock);assert.equal(challenger.rulesVersion,3);assert.equal(challenger.feeBps,3);assert.equal(challenger.day,300);assert.equal(challenger.challengeScore,null);
 assert.equal((await f.call('records?record='+r,b)).status,404);assert.equal((await f.call('showcase/withdraw',b,{record:r})).status,404);await f.ok('showcase/withdraw',a,{record:r});assert.equal((await f.ok('showcase',b)).records.length,0);assert.equal((await f.call('showcase/challenge',b,{id:pub.id})).status,404);
 const final=await f.ok('action',b,{type:'fastForward',days:200,revision:challenger.revision},challenger.id);assert.equal(final.reveal,null);assert.equal(final.challengeScore.nickname,'战绩甲');assert.equal(final.challengeScore.metrics.returnPct,s.metrics.returnPct);
 const csv=await(await f.call('export?kind=rounds',b)).text();assert.match(csv,/超额夏普/);assert.match(csv,/超额卡玛/);assert.match(csv,new RegExp(pub.id));
 // An opt-in legacy showcase challenge keeps its original 200-day start and never reveals the stock.
 const old=createCompatible('stock',0,{mode:'test',feeBps:3},1);Object.assign(old,{ownerId:original.ownerId,recordId:'old-test'});const oldDone=act(act(old,rows,{type:'fastForward',days:200}),rows,{type:'fastForward',days:100});oldDone.summary=summarize(oldDone,data);await f.store.insert('e'.repeat(68),oldDone);const oldPub=await f.ok('showcase/publish',a,{record:'old-test'}),oldChallenge=await f.ok('showcase/challenge',b,{id:oldPub.id}),oc=await f.ok('records?record='+oldChallenge.recordId,b);assert.equal(oc.day,200);assert.equal(oc.rulesVersion,1);let of=await f.ok('action',b,{type:'fastForward',days:200,revision:oc.revision},oc.id);of=await f.ok('action',b,{type:'fastForward',days:100,revision:of.revision},oc.id);assert.equal(of.reveal,null);
 }finally{f.db.close()}
});
test('PK early-start unanimous votes reset on join, uses actual participant count and limits completed peer records',async()=>{
 const f=fixture();try{const a=await f.user('提前房主'),b=await f.user('提前成员'),c=await f.user('新加入'),d=await f.user('局外人'),room=await f.ok('pk/create',a,{capacity:4}),code=room.code;
 await f.ok('pk/consent',a,{code,agree:true});assert.equal((await f.call('pk/start',a,{code})).status,409);const rb=await f.ok('pk/join',b,{code});assert.equal(rb.members.find(m=>m.host).consent,false);
 await f.ok('pk/consent',a,{code,agree:true});await f.ok('pk/consent',b,{code,agree:true});assert.equal((await f.ok('pk?code='+code,a)).canStart,true);await f.ok('pk/join',c,{code});assert.equal((await f.call('pk/start',a,{code})).status,409);
 for(const u of [a,b,c])await f.ok('pk/consent',u,{code,agree:true});await f.ok('pk/consent',b,{code,agree:false});assert.equal((await f.call('pk/start',a,{code})).status,409);await f.ok('pk/consent',b,{code,agree:true});await f.ok('pk/start',a,{code});assert.equal((await f.store.pkRoom(code)).started_size,3);assert.equal((await f.call('pk/join',d,{code})).status,409);
 assert.equal((await f.call('pk/record?code='+code+'&record='+rb.myRecordId,a)).status,403);
 for(const u of [a,b,c]){const r=await f.ok('pk?code='+code,u),s=await f.ok('records?record='+r.myRecordId,u);await f.ok('action',u,{type:'fastForward',days:200,revision:s.revision},s.id)}
 const final=await f.ok('pk?code='+code,a);assert.equal(final.status,'done');assert.ok(final.members.every(m=>m.recordId));const peer=await f.ok('pk/record?code='+code+'&record='+rb.myRecordId,a);assert.equal(peer.nickname,'提前成员');assert.ok(Array.isArray(peer.trades));for(const field of ['id','ownerId','candles','reveal','stock'])assert.equal(peer[field],undefined);
 assert.equal((await f.call('pk/record?code='+code+'&record='+rb.myRecordId,d)).status,404);assert.equal((await f.call('records?record='+rb.myRecordId,a)).status,404);assert.equal((await f.call('pk/record?code='+code+'&record=not-in-room',a)).status,404);
 // Earlier room privacy remains unchanged even after all members finish.
 await f.db.prepare('UPDATE pk_rooms SET rules_version=2 WHERE code=?').bind(code).run();assert.equal((await f.call('pk/record?code='+code+'&record='+rb.myRecordId,a)).status,403);
 }finally{f.db.close()}
});

test('targetAdvance fills at the visible price once, advances whole days, holds when unchanged, and settles at the boundary',()=>{
 for(const phase of ['close','open'])for(const days of [1,5,20]){
  let s=createSession('stock',0,{feeBps:3});if(phase==='open')s=act(s,rows,{type:'next'});
  const before=structuredClone(s),price=rows[s.day][phase==='open'?1:4];
  const result=act(s,rows,{type:'targetAdvance',percent:50,days});
  assert.deepEqual(s,before);assert.equal(result.day,s.day+days);assert.equal(result.phase,'close');assert.equal(result.revision,s.revision+1);
  assert.equal(result.trades.length,1);near(result.trades[0].price,price);near(result.trades[0].positionAfter,50);assert.equal(result.trades[0].day,s.day+1);assert.equal(result.trades[0].phase,phase);
  const held=act(result,rows,{type:'targetAdvance',days:1});assert.equal(held.trades.length,1);near(held.shares,result.shares);
 }
 const empty=createSession('stock',0);const skipped=act(empty,rows,{type:'targetAdvance',percent:0,days:1});assert.equal(skipped.trades.length,0);assert.equal(skipped.day,300);
 for(const percent of [-1,101,null,'50',NaN])assert.throws(()=>act(empty,rows,{type:'targetAdvance',percent,days:1}));
 for(const days of [0,2,21,1.5])assert.throws(()=>act(empty,rows,{type:'targetAdvance',percent:50,days}));
 const late=act(empty,rows,{type:'fastForward',days:199}),done=act(late,rows,{type:'targetAdvance',percent:100,days:20});assert.equal(done.day,499);assert.equal(done.done,true);assert.equal(done.shares,0);assert.equal(done.trades.at(-1).forced,true);assert.equal(done.revision,late.revision+1);
 assert.throws(()=>act(done,rows,{type:'targetAdvance',percent:50,days:1}));
});
test('targetAdvance API commits trade and time atomically and rejects duplicate revisions',async()=>{
 const f=fixture();try{
 const user=await f.user('调仓推进验收'),s=await f.ok('session',user,{mode:'training'});
 const invalid=await f.call('action',user,{type:'targetAdvance',percent:50,days:0,revision:s.revision},s.id);assert.notEqual(invalid.status,200);
 const unchanged=await f.ok('session',user,undefined,s.id);assert.equal(unchanged.day,s.day);assert.equal(unchanged.trades.length,0);assert.equal(unchanged.revision,s.revision);
 const body={type:'targetAdvance',percent:50,days:5,revision:s.revision,compact:true};const delta=await f.ok('action',user,body,s.id),merged=mergeState(s,delta);assert.equal(merged.day,s.day+5);assert.equal(merged.trades.length,1);assert.equal(merged.revision,s.revision+1);
 assert.equal((await f.call('action',user,body,s.id)).status,409);const final=await f.ok('session',user,undefined,s.id);assert.equal(final.day,s.day+5);assert.equal(final.trades.length,1);
 }finally{f.db.close()}
});

test('corpus info distinguishes imported history, synthetic demo and unknown sources without exposing stocks',async()=>{
 for(const [source,kind] of [['本地日频 CSV','historical'],['Synthetic development data, not real prices','synthetic'],['unverified','unknown']]){
  const res=await handleApi(new Request('http://localhost/api/info'),{index:async()=>({source,stats:{eligibleStocks:1},stocks:[{key:'private-stock'}]})});
  const body=await res.json();assert.equal(body.dataKind,kind);assert.equal(body.stats.eligibleStocks,1);assert.equal(JSON.stringify(body).includes('private-stock'),false);
 }
});
