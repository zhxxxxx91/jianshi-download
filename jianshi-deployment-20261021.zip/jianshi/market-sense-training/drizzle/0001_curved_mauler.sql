CREATE TABLE `participant_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`nickname` text NOT NULL,
	`nickname_key` text NOT NULL,
	`salt` text NOT NULL,
	`password_hash` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `participant_accounts_nickname_key_unique` ON `participant_accounts` (`nickname_key`);--> statement-breakpoint
CREATE TABLE `auth_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`hits` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `participant_logins` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`expires` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `participant_accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `login_user_idx` ON `participant_logins` (`user_id`);--> statement-breakpoint
ALTER TABLE `training_sessions` ADD `owner_id` text REFERENCES participant_accounts(id);--> statement-breakpoint
ALTER TABLE `training_sessions` ADD `record_id` text;--> statement-breakpoint
ALTER TABLE `training_sessions` ADD `summary` text;--> statement-breakpoint
ALTER TABLE `training_sessions` ADD `created` text;--> statement-breakpoint
ALTER TABLE `training_sessions` ADD `done` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `record_id_idx` ON `training_sessions` (`record_id`);--> statement-breakpoint
CREATE INDEX `session_owner_created_idx` ON `training_sessions` (`owner_id`,`created`);--> statement-breakpoint
CREATE INDEX `session_created_idx` ON `training_sessions` (`created`);