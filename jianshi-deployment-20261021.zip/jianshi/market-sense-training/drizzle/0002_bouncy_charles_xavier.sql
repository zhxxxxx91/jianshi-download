ALTER TABLE `training_sessions` ADD `rules_version` integer DEFAULT 1 NOT NULL;--> statement-breakpoint
CREATE INDEX `session_version_created_idx` ON `training_sessions` (`rules_version`,`created`);