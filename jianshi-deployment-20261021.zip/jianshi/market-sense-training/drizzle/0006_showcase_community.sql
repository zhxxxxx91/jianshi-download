ALTER TABLE showcases ADD share_trades integer NOT NULL DEFAULT 0;
--> statement-breakpoint
CREATE TABLE showcase_comments (id text PRIMARY KEY NOT NULL, showcase_id text NOT NULL REFERENCES showcases(id), user_id text NOT NULL REFERENCES participant_accounts(id), body text NOT NULL CHECK(length(body) BETWEEN 1 AND 500), created text NOT NULL);
--> statement-breakpoint
CREATE INDEX showcase_comments_page ON showcase_comments(showcase_id,created,id);
--> statement-breakpoint
CREATE TABLE showcase_ratings (showcase_id text NOT NULL REFERENCES showcases(id), user_id text NOT NULL REFERENCES participant_accounts(id), score integer NOT NULL CHECK(score BETWEEN 1 AND 5), updated text NOT NULL, PRIMARY KEY(showcase_id,user_id));
