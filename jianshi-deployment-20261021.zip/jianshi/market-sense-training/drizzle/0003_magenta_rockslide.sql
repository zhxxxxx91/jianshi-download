CREATE TABLE `pk_members` (
	`room_code` text NOT NULL,
	`user_id` text NOT NULL,
	`session_id` text NOT NULL,
	`record_id` text NOT NULL,
	`joined` text NOT NULL,
	FOREIGN KEY (`room_code`) REFERENCES `pk_rooms`(`code`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`user_id`) REFERENCES `participant_accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pk_members_session_id_unique` ON `pk_members` (`session_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pk_members_record_id_unique` ON `pk_members` (`record_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pk_room_user_idx` ON `pk_members` (`room_code`,`user_id`);--> statement-breakpoint
CREATE INDEX `pk_user_idx` ON `pk_members` (`user_id`);--> statement-breakpoint
CREATE TABLE `pk_rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`capacity` integer NOT NULL,
	`stock` text NOT NULL,
	`start` integer NOT NULL,
	`fee_bps` integer NOT NULL,
	`created` text NOT NULL,
	`started` text,
	FOREIGN KEY (`owner_id`) REFERENCES `participant_accounts`(`id`) ON UPDATE no action ON DELETE no action
);
