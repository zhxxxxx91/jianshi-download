CREATE TABLE `training_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`revision` integer NOT NULL,
	`updated` integer NOT NULL
);
