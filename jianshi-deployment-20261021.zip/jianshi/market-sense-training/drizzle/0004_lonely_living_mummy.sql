CREATE TABLE `showcases` (
	`id` text PRIMARY KEY NOT NULL,
	`record_id` text NOT NULL,
	`owner_id` text NOT NULL,
	`created` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	FOREIGN KEY (`owner_id`) REFERENCES `participant_accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `showcases_record_id_unique` ON `showcases` (`record_id`);--> statement-breakpoint
CREATE INDEX `showcase_active_created_idx` ON `showcases` (`active`,`created`);--> statement-breakpoint
ALTER TABLE `pk_members` ADD `early_consent_count` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `pk_rooms` ADD `rules_version` integer DEFAULT 2 NOT NULL;--> statement-breakpoint
ALTER TABLE `pk_rooms` ADD `started_size` integer;