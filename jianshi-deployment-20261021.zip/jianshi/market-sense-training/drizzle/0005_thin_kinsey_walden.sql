ALTER TABLE `pk_rooms` ADD `visibility` text DEFAULT 'private' NOT NULL;--> statement-breakpoint
CREATE INDEX `pk_visibility_created_idx` ON `pk_rooms` (`visibility`,`created`);