export const defaultIndicators=()=>({maEnabled:true,maPeriods:[5,20,60],macdEnabled:false,fast:12,slow:26,signal:9});
export function normalizeIndicators(input={}){
  const p={...defaultIndicators(),...input};
  if(!Array.isArray(p.maPeriods)||p.maPeriods.length!==3||!p.maPeriods.every(n=>Number.isInteger(n)&&n>=1&&n<=250))throw Error('三条均线周期须为 1–250 的整数。');
  if(![p.fast,p.slow,p.signal].every(n=>Number.isInteger(n)&&n>=1&&n<=250)||p.fast>=p.slow)throw Error('MACD 周期须为 1–250 的整数，快线周期必须小于慢线。');
  return {maEnabled:!!p.maEnabled,maPeriods:[...p.maPeriods],macdEnabled:!!p.macdEnabled,fast:p.fast,slow:p.slow,signal:p.signal};
}
export function sma(values,period){let total=0;return values.map((v,i)=>{total+=v;if(i>=period)total-=values[i-period];return i<period-1?null:total/period})}
// EMA is seeded from the first known close; never include an unfinished candle.
export function ema(values,period){let previous;const a=2/(period+1);return values.map(v=>previous=previous===undefined?v:a*v+(1-a)*previous)}
export function calculateIndicators(candles,settings){const p=normalizeIndicators(settings),values=candles.filter(b=>b.complete!==false&&Number.isFinite(b.close)).map(b=>b.close),fast=ema(values,p.fast),slow=ema(values,p.slow),dif=fast.map((v,i)=>v-slow[i]),dea=ema(dif,p.signal);return {ma:p.maPeriods.map(n=>sma(values,n)),dif,dea,hist:dif.map((v,i)=>2*(v-dea[i])),count:values.length}}
export function candleReturn(candles,index){if(index<1)return null;const b=candles[index],previous=candles[index-1].close,price=b.complete===false?b.open:b.close;return previous>0?(price/previous-1)*100:null}
export const tradeLabels={open:'建仓',add:'加仓',reduce:'减仓',close:'清仓'};
