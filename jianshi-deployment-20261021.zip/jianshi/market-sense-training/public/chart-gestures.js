// Shared gesture math keeps a pinch anchored under the fingers rather than jumping to the end.
export function zoomWindow(view,factor,ratio,max){
 const count=Math.max(15,Math.min(max,view.count*factor));
 return {count,end:Math.max(count,Math.min(max,view.end+(count-view.count)*(1-Math.max(0,Math.min(1,ratio)))))};
}
export function attachChartGestures(canvas,{getView,getDays,draw}){
 const points=new Map();let drag=null,pinch=null,hold=null,scrub=false;
 const point=e=>({x:e.clientX,y:e.clientY});
 const hover=p=>{const r=canvas.getBoundingClientRect();getView().hover={x:p.x-r.left,y:p.y-r.top}};
 const clearHold=()=>{clearTimeout(hold);hold=null};
 function baseline(){const p=[...points.values()][0];drag=p?{...p,end:getView().end,moved:true}:null;pinch=null;scrub=false}
 canvas.onpointerdown=e=>{
  if(!getDays())return;clearHold();points.set(e.pointerId,point(e));canvas.setPointerCapture(e.pointerId);
  if(points.size===1){drag={...point(e),end:getView().end,moved:false};scrub=false;if(e.pointerType!=='mouse')hold=setTimeout(()=>{scrub=true;hover(point(e));draw()},350)}
  if(points.size===2){const [a,b]=[...points.values()],r=canvas.getBoundingClientRect();pinch={distance:Math.max(10,Math.hypot(a.x-b.x,a.y-b.y)),view:{...getView()},ratio:((a.x+b.x)/2-r.left-12)/Math.max(1,r.width-80)};scrub=false;getView().hover=null}
 };
 canvas.onpointermove=e=>{
  if(!getDays())return;const v=getView(),r=canvas.getBoundingClientRect();if(points.has(e.pointerId))points.set(e.pointerId,point(e));
  if(points.size===2&&pinch){clearHold();const [a,b]=[...points.values()];Object.assign(v,zoomWindow(pinch.view,pinch.distance/Math.max(10,Math.hypot(a.x-b.x,a.y-b.y)),pinch.ratio,getDays()));v.hover=null}
  else if(drag&&points.size===1){if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>6){drag.moved=true;clearHold()}if(scrub)hover(point(e));else if(drag.moved){v.end=Math.max(v.count,Math.min(getDays(),drag.end-(e.clientX-drag.x)/Math.max(1,r.width-80)*v.count));v.hover=null}}
  else if(e.pointerType==='mouse')hover(point(e));draw();
 };
 const end=e=>{clearHold();if(e.type==='pointerup'&&points.size===1&&drag&&!drag.moved&&!pinch){hover(point(e));draw()}points.delete(e.pointerId);baseline()};
 canvas.onpointerup=end;canvas.onpointercancel=end;canvas.onlostpointercapture=e=>{if(points.has(e.pointerId))end(e)};
 canvas.onpointerleave=e=>{if(e.pointerType==='mouse'&&!points.size){getView().hover=null;draw()}};
 canvas.onwheel=e=>{if(!getDays())return;e.preventDefault();const r=canvas.getBoundingClientRect();Object.assign(getView(),zoomWindow(getView(),e.deltaY>0?1.14:.88,(e.clientX-r.left-12)/Math.max(1,r.width-80),getDays()));getView().hover=null;draw()};
 canvas.onkeydown=e=>{if(!getDays())return;const v=getView();if(e.key==='ArrowLeft'||e.key==='ArrowRight'){v.end=Math.max(v.count,Math.min(getDays(),v.end+(e.key==='ArrowLeft'?-1:1)*Math.max(1,Math.round(v.count/8))))}else if(e.key==='+'||e.key==='=')Object.assign(v,zoomWindow(v,.75,1,getDays()));else if(e.key==='-')Object.assign(v,zoomWindow(v,1.3,1,getDays()));else if(e.key==='End')v.end=getDays();else return;e.preventDefault();e.stopPropagation();v.hover=null;draw()};
}
