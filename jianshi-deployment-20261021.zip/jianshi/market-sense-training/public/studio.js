import './theme.js';
// Presentation controls only; session state and all fills remain server-owned.
const $ = id => document.getElementById(id);
const slider = $('positionSlider'), input = $('percent');
slider.addEventListener('input', () => { input.value = slider.value; input.dispatchEvent(new Event('input', {bubbles:true})); });
input.addEventListener('input', () => {
  const valid = input.value.trim() !== '' && input.checkValidity();
  input.setAttribute('aria-invalid', String(!valid));
  if (valid) slider.value = input.value;
});
const tabs = [$('curveTab'), $('logTab')];
function selectTab(tab) {
  for (const item of tabs) {
    const selected = item === tab;
    item.setAttribute('aria-selected', String(selected));
    item.tabIndex = selected ? 0 : -1;
    $(item.getAttribute('aria-controls')).hidden = !selected;
  }
  window.dispatchEvent(new Event('jianshi:appearance'));
}
for (const tab of tabs) {
  tab.addEventListener('click', () => selectTab(tab));
  tab.addEventListener('keydown', event => {
    if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    event.preventDefault(); event.stopPropagation();
    const next = event.key === 'Home' ? tabs[0] : event.key === 'End' ? tabs[1] : tabs[1-tabs.indexOf(tab)];
    selectTab(next); next.focus();
  });
}

function markPosition(){const v=Number(input.value),valid=input.value.trim()!==''&&input.checkValidity();input.setAttribute('aria-invalid',String(!valid));for(const [id,value] of [['clearBtn',0],['quarterBtn',25],['halfBtn',50],['threeQuarterBtn',75],['fullBtn',100]])$(id).setAttribute('aria-pressed',String(valid&&Math.abs(v-value)<.01))}
input.addEventListener('input',markPosition);window.addEventListener('jianshi:position',markPosition);markPosition();
