const themeButton = document.getElementById('themeToggle');
function refreshThemeLabel() {
  const dark = document.documentElement.dataset.theme === 'dark';
  themeButton.textContent = dark ? '浅色' : '深色';
  themeButton.setAttribute('aria-label', dark ? '切换浅色模式' : '切换深色模式');
  themeButton.setAttribute('aria-pressed', String(dark));
}
themeButton.addEventListener('click', () => {
  const theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem('jianshi-theme', theme); } catch { /* Storage may be disabled. */ }
  refreshThemeLabel();
  window.dispatchEvent(new Event('jianshi:appearance'));
});
refreshThemeLabel();
