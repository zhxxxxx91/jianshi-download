export function chartWindow(n,view,left,right){
  const count=Math.min(n,Math.max(15,Math.round(view.count))),end=Math.min(n,Math.max(count,Math.round(view.end))),start=end-count;
  const inset=12,origin=left+inset,step=Math.max(1,right-left-inset*2)/count;
  return {count,start,end,step,origin,x:i=>origin+(i-start+.5)*step};
}
