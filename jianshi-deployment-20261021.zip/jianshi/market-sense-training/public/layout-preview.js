// Approved homepage plus optional B/C comparisons. Moves nodes; never copies trading state.
const requestedLayout=new URLSearchParams(location.search).get('layout');
const choice=['b','c'].includes(requestedLayout)?requestedLayout:'a';
if(['a','b','c'].includes(choice)){
 const css=document.createElement('link');css.rel='stylesheet';css.href='/layout-preview.css';document.head.append(css);
 document.body.classList.add('layout-preview','layout-'+choice);
 const bar=document.createElement('section');bar.className='layout-comparison';bar.setAttribute('aria-label','布局方案预览');
 bar.innerHTML='<span>布局预览 · 尚未定稿</span><nav>'+[['a','A 账户集中'],['b','B 图下摘要'],['c','C 按用途分布']].map(([key,label])=>'<a href="?layout='+key+'"'+(key===choice?' aria-current="page"':'')+'>'+label+'</a>').join('')+'</nav><a href="/">退出预览</a>';
 if(choice!=='a')document.querySelector('main').before(bar);
 const metrics=document.querySelector('.metrics-v2'),items=[...metrics.children],trade=document.querySelector('.trade-panel'),balances=document.querySelector('.balances'),intro=document.querySelector('.intro'),risk=document.querySelector('.risk-details');
 intro.classList.add('brand-signoff');document.querySelector('footer').before(intro);
 function group(className,title,nodes){const box=document.createElement('section');box.className='metric-group '+className;box.innerHTML='<h3>'+title+'</h3><div class="metric-items"></div>';box.lastElementChild.append(...nodes);return box;}
 if(choice==='a'){
  const cache=document.createElement('div');cache.hidden=true;cache.className='metrics-cache';cache.append(...items,risk,document.querySelector('#tradeHint'),document.querySelector('#nextHint'));document.querySelector('main').append(cache);
  const box=document.createElement('section');box.className='account-summary';box.innerHTML='<h3>账户概览</h3>';box.append(balances);
  const fast=document.querySelector('#ff5').parentElement,fastHint=fast.nextElementSibling;cache.append(fastHint);
  const tools=document.querySelector('.round-tools');trade.append(box,tools);const actions=document.querySelector('.decision-bar');actions.append(document.querySelector('#ff5'),document.querySelector('#ff20'));fast.remove();document.querySelector('#ff5').textContent='5 天';document.querySelector('#ff20').textContent='20 天';
  const label=document.querySelector('#inputLabel'),labelRow=document.createElement('div');labelRow.className='position-label';label.before(labelRow);labelRow.append(label);const currentPosition=document.createElement('span');currentPosition.id='mobilePosition';currentPosition.textContent='当前 0.0%';labelRow.append(currentPosition);
  const info=document.createElement('span');info.className='trade-info';info.innerHTML='<button type="button" class="info-button" aria-label="调仓说明" aria-describedby="positionHelp" aria-expanded="false">i</button><span id="positionHelp" class="info-tooltip" role="tooltip">按当前显示的开盘／收盘价调仓，再推进 1、5 或 20 个交易日至收盘。未改仓位则只推进；途中不交易，最晚止于第 500 天。</span>';labelRow.append(info);
  const button=info.querySelector('button');function closeInfo(){info.classList.remove('is-open');info.classList.add('is-dismissed');button.setAttribute('aria-expanded','false')}
  info.addEventListener('pointerenter',()=>info.classList.remove('is-dismissed'));button.addEventListener('focus',()=>info.classList.remove('is-dismissed'));
  button.addEventListener('click',()=>{if(info.classList.contains('is-open')){closeInfo();return}info.classList.remove('is-dismissed');info.classList.add('is-open');button.setAttribute('aria-expanded','true')});
  document.addEventListener('click',event=>{if(!info.contains(event.target))closeInfo()});
  info.addEventListener('keydown',event=>{if(event.key==='Escape'){closeInfo();button.blur()}});
  const finish=document.createElement('link');finish.rel='stylesheet';finish.href='/layout-balanced.css';document.head.append(finish);
  const accountDetails=document.createElement('details');accountDetails.className='mobile-account-details';accountDetails.innerHTML='<summary>账户明细</summary>';box.querySelector('h3').after(accountDetails);accountDetails.append(balances);
  const media=matchMedia('(max-width:760px)');const setDetails=()=>{accountDetails.open=!media.matches};media.addEventListener('change',setDetails);setDetails();
  const mobileCss=document.createElement('link');mobileCss.rel='stylesheet';mobileCss.href='/mobile-studio.css';document.head.append(mobileCss);

 }else if(choice==='b'){
  document.querySelector('.chart-panel').append(group('chart-summary','本轮表现',items));document.querySelector('.review-tabs').before(risk);
 }else{
  document.querySelector('.field-label').before(group('position-summary','当前持仓',[items[2]]));
  balances.before(group('asset-summary','账户概览',[items[0],items[1]]));
  document.querySelector('.curve-panel .panel-head').after(group('performance-summary','风险与表现',[items[3],items[4]]));document.querySelector('.curve-panel').append(risk);
 }
 metrics.remove();window.dispatchEvent(new Event('jianshi:appearance'));
}
