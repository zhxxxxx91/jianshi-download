export function mergeState(old,patch){
  if(!patch.patch)return patch;
  if(!old||old.id!==patch.id||old.revision!==patch.baseRevision)throw Error('进度不同步，请刷新恢复。');
  const next={...old,...patch};for(const key of ['candles','trades','equity','indicatorHistory']){next[key]=[...(old[key]||[]).slice(0,patch[key+'From']),...patch[key]];delete next[key+'From']}
  delete next.patch;delete next.baseRevision;return next;
}
