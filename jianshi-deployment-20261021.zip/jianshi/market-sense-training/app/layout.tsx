import type {Metadata} from 'next';
export const metadata:Metadata={title:'见势 · 盘感训练',description:'隐去名字，看见趋势。用真实历史行情训练交易决策。',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:Readonly<{children:React.ReactNode}>){return <html lang="zh-CN"><body style={{margin:0,background:'#101816'}}>{children}</body></html>}
