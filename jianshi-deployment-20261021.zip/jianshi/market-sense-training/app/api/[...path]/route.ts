import {env} from 'cloudflare:workers';
// @ts-ignore Shared server modules also power the standalone local version.
import {handleApi} from '../../../lib/api.mjs';
// @ts-ignore Shared parameterized SQL adapter.
import {createStore} from '../../../lib/store.mjs';
// @ts-ignore Immutable corpus cache shared across requests.
import {cachedCorpus} from '../../../lib/corpus-cache.mjs';
export const dynamic='force-dynamic';
const bindings=()=>env as unknown as {DB:D1Database;BUCKET:R2Bucket;ACCOUNT_PASSWORD_PEPPER?:string;SITE_OWNER_EMAIL?:string};
const corpus=cachedCorpus({
  async index(){const o=await bindings().BUCKET.get('corpus/index.json');if(!o)throw Error('行情数据正在导入，请稍后再试。');return o.json()},
  async stock(key:string){const o=await bindings().BUCKET.get('corpus/'+key+'.json.gz');if(!o)throw Error('未找到行情数据');return new Response(o.body.pipeThrough(new DecompressionStream('gzip'))).json()}
});
async function serve(req:Request){
  const {DB,BUCKET,ACCOUNT_PASSWORD_PEPPER,SITE_OWNER_EMAIL}=bindings();
  if(new URL(req.url).pathname==='/api/import')return new Response('Forbidden',{status:403});
  const storage=createStore(DB,corpus);
  return handleApi(req,storage,{pepper:ACCOUNT_PASSWORD_PEPPER,ownerEmail:SITE_OWNER_EMAIL});
}
export const GET=serve;export const POST=serve;
