export default function Home(){return <iframe title="见势 · 盘感训练" src="/trainer.html" style={{border:0,width:'100%',height:'100dvh',display:'block'}}/>}
